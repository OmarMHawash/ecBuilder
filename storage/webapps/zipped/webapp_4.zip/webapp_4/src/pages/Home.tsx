import React from 'react'

const Home = (): JSX.Element => {
  return <main></main>
}

export default Home
